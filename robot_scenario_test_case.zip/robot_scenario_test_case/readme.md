# Robot Scenario Test
1. run API server
2. run Robot Test

## Test Case
robot -i **tag name**
- All
``
robot .
``
- PO document
``
robot -i po .
``
- SO document
``
robot -i so .
``

## Open Document Scenario Test
``
open test\ case.pdf
``
